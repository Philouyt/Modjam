package com.aven.aventurus.init;

import com.aven.aventurus.AVENTURUS;
import com.aven.aventurus.utils.ModitemGroups;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraftforge.common.ToolType;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import org.lwjgl.system.CallbackI;

import java.rmi.registry.Registry;
import java.util.function.Supplier;
public class Modblock {

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, AVENTURUS.MODID);


    public static final RegistryObject<Block> SILVER_BLOCK = createBlocks("silver_block", () -> new Block(AbstractBlock.Properties.create(Material.IRON).hardnessAndResistance(3f,20f).harvestTool(ToolType.PICKAXE).harvestLevel(2).setRequiresTool()));
    public static final RegistryObject<Block> SILVER_ORE = createBlocks("silver_ore", () -> new Block(AbstractBlock.Properties.create(Material.ROCK).hardnessAndResistance(3f,20f).harvestTool(ToolType.PICKAXE).harvestLevel(2).setRequiresTool()));
    public static final RegistryObject<Block> BREAK_STONE_BLOCK = createBlocks("break_stone_block", () -> new Block(AbstractBlock.Properties.create(Material.IRON).hardnessAndResistance(3f,10f).harvestTool(ToolType.PICKAXE).harvestLevel(1).setRequiresTool()));
    public static final RegistryObject<Block> BREAK_STONE_ORE = createBlocks("break_stone_ore", () -> new Block(AbstractBlock.Properties.create(Material.ROCK).hardnessAndResistance(3f,10f).harvestTool(ToolType.PICKAXE).harvestLevel(1).setRequiresTool()));
    public static final RegistryObject<Block> LEMON_BUSH = createBlocks("lemon_bush", () -> new Block(AbstractBlock.Properties.create(Material.LEAVES).hardnessAndResistance(1f,2f).harvestTool(ToolType.PICKAXE).harvestLevel(0)));
    public static final RegistryObject<Block> COOPER_BLOCK = createBlocks("cooper_block", () -> new Block(AbstractBlock.Properties.create(Material.IRON).hardnessAndResistance(3f,20f).harvestTool(ToolType.PICKAXE).harvestLevel(1).setRequiresTool()));
    public static final RegistryObject<Block> COOPER_ORE = createBlocks("cooper_ore", () -> new Block(AbstractBlock.Properties.create(Material.ROCK).hardnessAndResistance(3f,20f).harvestTool(ToolType.PICKAXE).harvestLevel(1).setRequiresTool()));
    public static final RegistryObject<Block> AMETHYST_BLOCK = createBlocks("amethyst_block", () -> new Block(AbstractBlock.Properties.create(Material.IRON).hardnessAndResistance(3f,25f).harvestTool(ToolType.PICKAXE).harvestLevel(2).setRequiresTool()));
    public static final RegistryObject<Block> AMETHYST_ORE = createBlocks("amethyst_ore", () -> new Block(AbstractBlock.Properties.create(Material.ROCK).hardnessAndResistance(3f,25f).harvestTool(ToolType.PICKAXE).harvestLevel(2).setRequiresTool()));








    public static RegistryObject<Block> createBlocks(String name, Supplier<? extends Block> supplier)
    {
        RegistryObject<Block> block = BLOCKS.register(name, supplier);
        Moditems.ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties().group(ModitemGroups.AVENTURUS_TAB)));
        return block;
    }
}
