package com.aven.aventurus.init;
import com.aven.aventurus.AVENTURUS;
import com.aven.aventurus.utils.*;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.*;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import org.lwjgl.system.CallbackI;

public class Moditems
{

    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, AVENTURUS.MODID);

    public static final Item.Properties groupItem = new Item.Properties().group(ModitemGroups.AVENTURUS_TAB);

    public static final RegistryObject<Item> SILVER_INGOT = ITEMS.register("silver_ingot", () -> new Item(new Item.Properties().group(ModitemGroups.AVENTURUS_TAB)));
    public static final RegistryObject<Item> SILVER_SWORD = ITEMS.register("silver_sword", () -> new SwordItem(CustomItemTiers.SILVER,5, -2.8F, new Item.Properties().maxStackSize(1).group(ModitemGroups.AVENTURUS_TAB)));
    public static final RegistryObject<Item> SILVER_PICKAXE = ITEMS.register("silver_pickaxe", () -> new PickaxeItem(CustomItemTiers.SILVER,0, -2.5F, new Item.Properties().maxStackSize(1).group(ModitemGroups.AVENTURUS_TAB)));
    public static final RegistryObject<Item> SILVER_AXE = ITEMS.register("silver_axe", () -> new AxeItem(CustomItemTiers.SILVER,0, -2.5F, new Item.Properties().maxStackSize(1).group(ModitemGroups.AVENTURUS_TAB)));
    public static final RegistryObject<Item> SILVER_SHOVEL = ITEMS.register("silver_shovel", () -> new ShovelItem(CustomItemTiers.SILVER,0, -2.5F, new Item.Properties().maxStackSize(1).group(ModitemGroups.AVENTURUS_TAB)));
    public static final RegistryObject<Item> SILVER_HELMET = ITEMS.register("silver_helmet", () -> new ArmorItem(CustomAmorMaterials.SILVER_ARMOR, EquipmentSlotType.HEAD, new Item.Properties().maxStackSize(1).group(ModitemGroups.AVENTURUS_TAB)));
    public static final RegistryObject<Item> SILVER_CHESTPLATE = ITEMS.register("silver_chestplate", () -> new ArmorItem(CustomAmorMaterials.SILVER_ARMOR, EquipmentSlotType.CHEST, new Item.Properties().maxStackSize(1).group(ModitemGroups.AVENTURUS_TAB)));
    public static final RegistryObject<Item> SILVER_LEGGINGS = ITEMS.register("silver_leggings", () -> new ArmorItem(CustomAmorMaterials.SILVER_ARMOR, EquipmentSlotType.LEGS, new Item.Properties().maxStackSize(1).group(ModitemGroups.AVENTURUS_TAB)));
    public static final RegistryObject<Item> SILVER_BOOTS = ITEMS.register("silver_boots", () -> new ArmorItem(CustomAmorMaterials.SILVER_ARMOR, EquipmentSlotType.FEET, new Item.Properties().maxStackSize(1).group(ModitemGroups.AVENTURUS_TAB)));

    public static final RegistryObject<Item> BREAK_STONE_INGOT = ITEMS.register("break_stone_ingot", () -> new Item(new Item.Properties().group(ModitemGroups.AVENTURUS_TAB)));
    public static final RegistryObject<Item> BREAK_STONE_SWORD = ITEMS.register("break_stone_sword", () -> new SwordItem(CustomItemTiers2.BREAK_STONE,4, -3.0F, new Item.Properties().maxStackSize(1).group(ModitemGroups.AVENTURUS_TAB)));
    public static final RegistryObject<Item> BREAK_STONE_PICKAXE = ITEMS.register("break_stone_pickaxe", () -> new PickaxeItem(CustomItemTiers2.BREAK_STONE,0, -2.8F, new Item.Properties().maxStackSize(1).group(ModitemGroups.AVENTURUS_TAB)));
    public static final RegistryObject<Item> BREAK_STONE_AXE = ITEMS.register("break_stone_axe", () -> new AxeItem(CustomItemTiers2.BREAK_STONE,0, -2.8F, new Item.Properties().maxStackSize(1).group(ModitemGroups.AVENTURUS_TAB)));
    public static final RegistryObject<Item> BREAK_STONE_SHOVEL = ITEMS.register("break_stone_shovel", () -> new ShovelItem(CustomItemTiers2.BREAK_STONE,0, -2.8F, new Item.Properties().maxStackSize(1).group(ModitemGroups.AVENTURUS_TAB)));
    public static final RegistryObject<Item> BREAK_STONE_HELMET = ITEMS.register("break_stone_helmet", () -> new ArmorItem(CustomAmorMaterials2.BREAK_STONE_ARMOR, EquipmentSlotType.HEAD, new Item.Properties().maxStackSize(1).group(ModitemGroups.AVENTURUS_TAB)));
    public static final RegistryObject<Item> BREAK_STONE_CHESTPLATE = ITEMS.register("break_stone_chestplate", () -> new ArmorItem(CustomAmorMaterials2.BREAK_STONE_ARMOR, EquipmentSlotType.CHEST, new Item.Properties().maxStackSize(1).group(ModitemGroups.AVENTURUS_TAB)));
    public static final RegistryObject<Item> BREAK_STONE_LEGGINGS = ITEMS.register("break_stone_leggings", () -> new ArmorItem(CustomAmorMaterials2.BREAK_STONE_ARMOR, EquipmentSlotType.LEGS, new Item.Properties().maxStackSize(1).group(ModitemGroups.AVENTURUS_TAB)));
    public static final RegistryObject<Item> BREAK_STONE_BOOTS = ITEMS.register("break_stone_boots", () -> new ArmorItem(CustomAmorMaterials2.BREAK_STONE_ARMOR, EquipmentSlotType.FEET, new Item.Properties().maxStackSize(1).group(ModitemGroups.AVENTURUS_TAB)));


    public static final RegistryObject<Item> LEMON = ITEMS.register("lemon", () -> new Item(new Item.Properties().group(ModitemGroups.AVENTURUS_TAB).food(new Food.Builder().hunger(4).saturation(1.5F).setAlwaysEdible().fastToEat().build())));
    public static final RegistryObject<Item> LEMONADE = ITEMS.register("lemonade", () -> new Item(new Item.Properties().group(ModitemGroups.AVENTURUS_TAB).food(new Food.Builder().hunger(3).saturation(1.5F).setAlwaysEdible().fastToEat().build())) {@Override public UseAction getUseAction(ItemStack stack) { return UseAction.DRINK; }});

    public static final RegistryObject<Item> COOPER_INGOT = ITEMS.register("cooper_ingot", () -> new Item(new Item.Properties().group(ModitemGroups.AVENTURUS_TAB)));
    public static final RegistryObject<Item> COOPER_SWORD = ITEMS.register("cooper_sword", () -> new SwordItem(CustomItemTiers3.COOPER,5, -2.6F, new Item.Properties().maxStackSize(1).group(ModitemGroups.AVENTURUS_TAB)));
    public static final RegistryObject<Item> COOPER_PICKAXE = ITEMS.register("cooper_pickaxe", () -> new PickaxeItem(CustomItemTiers3.COOPER,0, -2.4F, new Item.Properties().maxStackSize(1).group(ModitemGroups.AVENTURUS_TAB)));
    public static final RegistryObject<Item> COOPER_AXE = ITEMS.register("cooper_axe", () -> new AxeItem(CustomItemTiers3.COOPER,0, -2.4F, new Item.Properties().maxStackSize(1).group(ModitemGroups.AVENTURUS_TAB)));
    public static final RegistryObject<Item> COOPER_SHOVEL = ITEMS.register("cooper_shovel", () -> new ShovelItem(CustomItemTiers3.COOPER,0, -2.4F, new Item.Properties().maxStackSize(1).group(ModitemGroups.AVENTURUS_TAB)));
    public static final RegistryObject<Item> COOPER_HELMET = ITEMS.register("cooper_helmet", () -> new ArmorItem(CustomAmorMaterials3.COOPER_ARMOR, EquipmentSlotType.HEAD, new Item.Properties().maxStackSize(1).group(ModitemGroups.AVENTURUS_TAB)));
    public static final RegistryObject<Item> COOPER_CHESTPLATE = ITEMS.register("cooper_chestplate", () -> new ArmorItem(CustomAmorMaterials3.COOPER_ARMOR, EquipmentSlotType.CHEST, new Item.Properties().maxStackSize(1).group(ModitemGroups.AVENTURUS_TAB)));
    public static final RegistryObject<Item> COOPER_LEGGINGS = ITEMS.register("cooper_leggings", () -> new ArmorItem(CustomAmorMaterials3.COOPER_ARMOR, EquipmentSlotType.LEGS, new Item.Properties().maxStackSize(1).group(ModitemGroups.AVENTURUS_TAB)));
    public static final RegistryObject<Item> COOPER_BOOTS = ITEMS.register("cooper_boots", () -> new ArmorItem(CustomAmorMaterials3.COOPER_ARMOR, EquipmentSlotType.FEET, new Item.Properties().maxStackSize(1).group(ModitemGroups.AVENTURUS_TAB)));

    public static final RegistryObject<Item> AMETHYST_INGOT = ITEMS.register("amethyst_ingot", () -> new Item(new Item.Properties().group(ModitemGroups.AVENTURUS_TAB)));
    public static final RegistryObject<Item> AMETHYST_SWORD = ITEMS.register("amethyst_sword", () -> new SwordItem(CustomItemTiers4.AMETHYST,5, -2.2F, new Item.Properties().maxStackSize(1).group(ModitemGroups.AVENTURUS_TAB)));
    public static final RegistryObject<Item> AMETHYST_PICKAXE = ITEMS.register("amethyst_pickaxe", () -> new PickaxeItem(CustomItemTiers4.AMETHYST,0, -2.0F, new Item.Properties().maxStackSize(1).group(ModitemGroups.AVENTURUS_TAB)));
    public static final RegistryObject<Item> AMETHYST_AXE = ITEMS.register("amethyst_axe", () -> new AxeItem(CustomItemTiers4.AMETHYST,0, -2.0F, new Item.Properties().maxStackSize(1).group(ModitemGroups.AVENTURUS_TAB)));
    public static final RegistryObject<Item> AMETHYST_SHOVEL = ITEMS.register("amethyst_shovel", () -> new ShovelItem(CustomItemTiers4.AMETHYST,0, -2.0F, new Item.Properties().maxStackSize(1).group(ModitemGroups.AVENTURUS_TAB)));
    public static final RegistryObject<Item> AMETHYST_HELMET = ITEMS.register("amethyst_helmet", () -> new ArmorItem(CustomAmorMaterials4.AMETHYST_ARMOR, EquipmentSlotType.HEAD, new Item.Properties().maxStackSize(1).group(ModitemGroups.AVENTURUS_TAB)));
    public static final RegistryObject<Item> AMETHYST_CHESTPLATE = ITEMS.register("amethyst_chestplate", () -> new ArmorItem(CustomAmorMaterials4.AMETHYST_ARMOR, EquipmentSlotType.CHEST, new Item.Properties().maxStackSize(1).group(ModitemGroups.AVENTURUS_TAB)));
    public static final RegistryObject<Item> AMETHYST_LEGGINGS = ITEMS.register("amethyst_leggings", () -> new ArmorItem(CustomAmorMaterials4.AMETHYST_ARMOR, EquipmentSlotType.LEGS, new Item.Properties().maxStackSize(1).group(ModitemGroups.AVENTURUS_TAB)));
    public static final RegistryObject<Item> AMETHYST_BOOTS = ITEMS.register("amethyst_boots", () -> new ArmorItem(CustomAmorMaterials4.AMETHYST_ARMOR, EquipmentSlotType.FEET, new Item.Properties().maxStackSize(1).group(ModitemGroups.AVENTURUS_TAB)));

    public static final RegistryObject<Item> ICE_TOOL = ITEMS.register("ice_tool", () -> new SwordItem(CustomItemTiers5.ICE,5, -2.0F, new Item.Properties().maxStackSize(1).group(ModitemGroups.AVENTURUS_TAB)));
}


