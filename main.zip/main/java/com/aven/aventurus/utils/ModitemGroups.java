package com.aven.aventurus.utils;

import com.aven.aventurus.init.Moditems;
import com.aven.aventurus.init.Moditems;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;

public class ModitemGroups {


public static final ItemGroup AVENTURUS_TAB = new ItemGroup("aventurustab") {
    @Override
    public ItemStack createIcon() {
        return new ItemStack(Moditems.SILVER_SWORD.get());
    }


};



}

