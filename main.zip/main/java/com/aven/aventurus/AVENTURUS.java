package com.aven.aventurus;

import com.aven.aventurus.init.*;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(AVENTURUS.MODID)
public class AVENTURUS
{

    public static final String MODID = "aventurus";

    public AVENTURUS()

    {

        FMLJavaModLoadingContext.get().getModEventBus().addListener(this ::setup);
        FMLJavaModLoadingContext.get().getModEventBus().addListener(this ::clientSetup);

        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        Moditems.ITEMS.register(bus);
        Modblock.BLOCKS.register(bus);

    }

    private void setup(FMLClientSetupEvent e)

    {

        ModFeatures features = new ModFeatures();
        features.init();
        MinecraftForge.EVENT_BUS.register(features);

        ModFeatures2 features2 = new ModFeatures2();
        features2.init();
        MinecraftForge.EVENT_BUS.register(features2);

        ModFeatures3 features3 = new ModFeatures3();
        features3.init();
        MinecraftForge.EVENT_BUS.register(features3);

        ModFeatures4 features4 = new ModFeatures4();
        features4.init();
        MinecraftForge.EVENT_BUS.register(features4);

        ModFeatures5 features5 = new ModFeatures5();
        features5.init();
        MinecraftForge.EVENT_BUS.register(features5);

        ModFeatures6 features6 = new ModFeatures6();
        features6.init();
        MinecraftForge.EVENT_BUS.register(features6);



    }
    private void clientSetup(FMLCommonSetupEvent e)

    {



    }
}
